
OPERATION_DICT = {}

def parse_operation(operation_string):
    return None